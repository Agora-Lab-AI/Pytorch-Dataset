from aoa_pytorch.aoa_pytorch import AttentionOnAttention
AoA = AttentionOnAttention
